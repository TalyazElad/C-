/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Class.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
// start the Class
Class::Class()
{
    numOfPupils = 0;
    layer = 0;
    numClass = 0;
    tutor = nullptr;
}
Class::~Class() {}
// add a pupil to the class (push the vector)
void Class::addPupiltoClass(Pupil *pupil)
{
    if (pupil)
    {
        pupilsAtClass.emplace_back(pupil);
        numOfPupils ++ ;
    }
}

//get the pupils vector of the class
Pupil * Class::getPupil(int idx)
{
    if (idx > numOfPupils && idx >=0)
    {
        return pupilsAtClass.at(idx);
    }
    return nullptr;
}

// sets the class num
void Class::setClassNum(int classnum)
{
    numClass = classnum;
}

// sets the layer that the class is in
void Class::setLayer(char Layer)
{
    layer = Layer;
}

// get back the class num
int Class::getClassNum()
{
    return numClass;
}

// gets back the layer that the class in
int Class::getLayer()
{
    return layer;
}

// get back the tutor of the class
Tutor * Class::getTutor()
{
    return tutor;
}

// get the pupils at the class
vector<Pupil *> Class::getPupil()
{
    return pupilsAtClass;
}

// print the class info : pupils and etc
void Class::printClass()
{
    int g = 1;
    cout << "Class: " << layer << numClass << endl;
    cout << "There are " << numOfPupils << " pupils in that class" << endl;
    if (numOfPupils != 0)
    {
        cout << "Pupils Names: " << endl;
        for (int i = 0; i < numOfPupils; ++i)
        {
            cout << pupilsAtClass.operator[](i)->getFirstName() ;
            cout << " " << pupilsAtClass.operator[](i)->getLastName();
            cout << ", average grade:" << pupilsAtClass[i]->salary() << endl;
        }
        float classaverage = 0 ;
        for (int i = 0; i < numOfPupils; ++i) {
            classaverage += pupilsAtClass[i]->salary();
        }
        classaverage = classaverage/numOfPupils;
        cout << "the average grade of the whole class is:" << classaverage << endl;
        for (int i = 0; i < numOfPupils; ++i) {
            if (pupilsAtClass[i]->isSuccessful())
            {
                if (g == 1)
                {
                    cout << "the successful pupils are: \n";
                }
                cout << pupilsAtClass[i]->getFirstName() << " " << pupilsAtClass[i]->getLastName() << endl;
                g++;

            }

        }
    }
}

// set the tutor of the class
void Class::setTutor(Tutor* tutor1)
{
    tutor = tutor1;
}
