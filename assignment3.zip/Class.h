/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_CLASS_H
#define ASSINGMENT3_CLASS_H
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Pupil.h"

class Tutor;
class Class {
private:
    char layer;
    int numClass;
    vector<Pupil*> pupilsAtClass;
    int numOfPupils;
    Tutor* tutor;
public:
    Class();
    virtual ~Class();
    void setTutor(Tutor* tutor1);
    vector<Pupil*> getPupil();
    Pupil* getPupil (int idx);
    void addPupiltoClass(Pupil* pupil);
    int getClassNum();
    void setClassNum(int classnum);
    void printClass();
    int getLayer();
    void setLayer(char Layer);
    Tutor* getTutor();
};


#endif //ASSINGMENT3_CLASS_H
