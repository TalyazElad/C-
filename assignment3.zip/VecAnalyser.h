/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_VECANALYSER_H
#define ASSINGMENT3_VECANALYSER_H
#include <iostream>
#include <cstring>
#include <sstream>
#include <typeinfo>
#include "Person.h"
#include "Pupil.h"

#include "Manager.h"
#include "Secretary.h"
#include "Tutor.h"
#include "Class.h"
#include "School.h"
using namespace std;


template <class T>
class VecAnalyser {
public:
    VecAnalyser();
    T* getbyIdx(vector<T*> schoolVec,int idx);
    void swap(vector<T> schoolVec ,int idx1, int idx2);
    void printElement(vector<T*> schoolVec ,int idx);
    void printMax(vector<T*> schoolVec);
    void printAll(vector<T*> schoolVec);

};

#endif //ASSINGMENT3_VECANALYSER_H
