/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/
#include <vector>
#include "VecAnalyser.h"



template<class T>
VecAnalyser<T>::VecAnalyser(){}
template<class T>
// swap function by index of two elements of the vector
void VecAnalyser<T>::swap(vector<T> schoolVec ,int idx1, int idx2) {
    {
        if (schoolVec.size() <= idx1 || schoolVec.size() <= idx2 || idx1 < 0 || idx2 < 0) {
            stringstream error;
            error << "Index Exception , Vector size is: " << schoolVec.size();
            if (schoolVec.size() <= idx1 || idx1 < 0) {
                error << " index: " << idx1 << " out of bounds";
            }
            if (schoolVec.size() <= idx2 || idx2 < 0) {
                {
                    error << " index: " << idx2 << " out of bounds";
                }
                error << endl;
                throw error.str();
            }
        }
        T temp = schoolVec[idx1];
        schoolVec[idx1] = schoolVec[idx2];
        schoolVec[idx2] = temp;
    }
}

template <class T>
// print the exact person (doing the selection of what kind person is it)
void VecAnalyser<T>::printElement(vector<T*> schoolVec, int idx)
{
    schoolVec.at(idx)->printDetail();
    cout << "--------------------------------\n";
}

template<class T>
// get the exact person by getting index in the vector
T* VecAnalyser<T>::getbyIdx(vector<T*> schoolVec, int idx) {
    if (idx < 0 || idx > schoolVec.size() - 1) {
        throw invalid_argument("invalid index.");
    }
    return schoolVec[idx];
}

template<class T>
// print all the people in the vector (doing the selection of what kind person is it)
void VecAnalyser<T>::printAll(vector<T *> schoolVec) {
    for (int i = 0; i < schoolVec.size(); ++i) {
        printElement(schoolVec,i);
    }

}

template<class T>
// print the max paid worker / max avarage student (doing the selection of what kind person is it)
void VecAnalyser<T>::printMax(vector<T*> schoolVec) {
    {
        int maxsalary = -1;
        int thisone = -1;
        for (int i = 0; i < schoolVec.size(); ++i) {
            if (schoolVec[i]->salary() > maxsalary)
            {
                maxsalary = schoolVec[i]->salary();
                thisone = i;
            }
        }
        printElement(schoolVec,thisone);
    }
}
