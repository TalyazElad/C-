/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Tutor.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Teacher.h"

// default
Tutor::Tutor() {tutorClass = nullptr;}
Tutor::~Tutor() {}

// calculate the salary of the tutor
float Tutor::getSalary()
{
    return Teacher::salary()+1000;
}

// checks if the tutor is successful
bool Tutor::isSuccessful()
{
    int successpupil = 0;
    for (int i = 0; i < tutorClass->getPupil().size(); ++i)
    {
        if (tutorClass->getPupil()[i]->isSuccessful())
        {
            successpupil++;
        }
    }
    if (successpupil >= tutorClass->getPupil().size()/2)
    {
        return true;
    }
    return false;
}

// get the tutor class
Class* Tutor::getClass()
{
    return tutorClass;
}

// sets the tutor class
void Tutor::setClass(Class *TutorClass)
{
    tutorClass = TutorClass;
}

// print the tutor details
void Tutor::printDetail()
{
    cout << "Tutor Name: " << getFirstName() << " " << getLastName() << endl;
    cout << "Tutor Id: " << getId() << endl;
    cout << "Tutor seniority: " << getTeachYears()+getManageYears() << endl;
    printSubjectTeacher();
    tutorClass->printClass();
    cout << "The Teacher salary is: " << getSalary() << endl;
}
