/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Person.h"
#include <iostream>
#include <string.h>
#include <cstring>
using namespace std;

Person::Person()
{}
//delete all the allocated data
Person::~Person()
{
    delete[] firstName ;
    delete[] lastName ;

}
// sets the first name
void Person::setFirstName(char *Firstname)
{
    firstName = new char [strlen(Firstname)+1];
    strcpy(firstName,Firstname);
}
// sets the second name
void Person::setLastName(char *Lastname)
{
    lastName = new char [strlen(Lastname)+1];
    strcpy(lastName,Lastname);
}

// get the first name
char* Person::getFirstName()
{
    return firstName;
}

//get the last name
char * Person::getLastName()
{
    return lastName;
}

// default
bool Person::isSuccessful()
{ return false; }

// sets the id of the person
void Person::setID(int id) {
    ID = id;

}

// get the id of the person
int Person::getId()
{
    return ID;
}

