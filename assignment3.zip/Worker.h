/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_WORKER_H
#define ASSINGMENT3_WORKER_H
#include "Person.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
using namespace std;

class Worker:public Person {
private:
     int manageYears ;
     int teachYears;
//     float salary ;
public:
    static int basis ;
    virtual float salary() = 0;
    Worker();
    virtual ~Worker();
    void setTeachYears(int seniority =0);
    void setmanageYears(int seniority=0);
    int getTeachYears();
    int getManageYears();
    virtual void printDetail() = 0;
//    void salaryWorker(int Salary);

};


#endif //ASSINGMENT3_WORKER_H
