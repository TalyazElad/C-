/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_MANAGER_H
#define ASSINGMENT3_MANAGER_H
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Teacher.h"
#include "AdministrationPersonal.h"
using namespace std;

class Manager :  public Teacher , public AdministrationPersonal  {
private:
    Manager();
public:
    static Manager* manager;
    virtual ~Manager();
    static Manager* createManager();
    virtual float salary();
    virtual bool isSuccessful();
    virtual void printDetail();
    bool isManagerTeach();


};


#endif //ASSINGMENT3_MANAGER_H
