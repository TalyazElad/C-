/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Worker.h"
#include "Person.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
using namespace std;
int Worker::basis = 25;
Worker::Worker()
{
//    manageYears = 0;
//    teachYears = 0;
}
Worker::~Worker() {}

// sets the teach years of the worker
void Worker::setTeachYears(int seniority )
{
    teachYears = seniority;
}

// sets the manage years of the worker
void Worker::setmanageYears(int seniority )
{
    manageYears = seniority;
}

// gets the manage years of the worker
int Worker::getManageYears()
{
    return manageYears;
}

// gets the teach years of the worker
int Worker::getTeachYears()
{
    return teachYears;
}
