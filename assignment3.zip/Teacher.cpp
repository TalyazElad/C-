/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Teacher.h"

#include <iostream>
#include <string>
#include <cstring>
#include <vector>
Teacher::Teacher() {}
Teacher::~Teacher() {}

// set the teacher subjects
void Teacher::setTeacherSubject(char* subject)
{
    subjects.emplace_back(subject);
    numSubjects = subjects.size();
}

// calculate the teacher salary
float Teacher::salary()
{
    float temp = numSubjects;
    float tmp = basis;
    return tmp*(1+(temp/10))+(300*(getTeachYears()+getManageYears()));

}

//checks if the teacher is successful
bool Teacher::isSuccessful()
{
    if (numSubjects < 5)
    {
        return 0;
    }
    return 1;
}

// print the teacher subjects
void Teacher::printSubjectTeacher()
{
    if (!numSubjects)
    {
        cout << "The teacher's subjebts are Null" << endl;
        return;
    }
    cout << "The subjects of the teacher are: ";
    for (int i = 0; i < numSubjects; ++i)
    {
        if (i == numSubjects - 1)
        {
            cout << subjects.at(i) << endl;
            return;
        }
        cout << subjects.at(i) << ", ";
    }
}

// print the teacher details
void Teacher::printDetail()
{
    cout << "Teacher Name: " << getFirstName() << " " << getLastName() << endl;
    cout << "Teacher Id: " << getId() << endl;
    cout << "Teacher seniority: " << getTeachYears()+getManageYears() << endl;
    printSubjectTeacher();
    cout << "The Teacher salary is: " << salary() << endl;
}
//Teacher Teacher::getTeacher()
//{
//    return
//}