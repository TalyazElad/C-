/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_TEACHER_H
#define ASSINGMENT3_TEACHER_H
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Person.h"
#include "Worker.h"
using namespace std;


class Teacher: virtual public Worker {
private:
    vector<string> subjects;
public:
    int numSubjects ;
    Teacher();
    virtual ~Teacher();
    void setTeacherSubject(char* subject );
    virtual float salary();
    Teacher getTeacher();
//    float SalaryofTeacher();
    virtual bool isSuccessful();
    void printSubjectTeacher();
    virtual void printDetail();
};


#endif //ASSINGMENT3_TEACHER_H
