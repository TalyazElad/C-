/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_LAYER_H
#define ASSINGMENT3_LAYER_H
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Class.h"

using namespace std;


class Layer {
private:
    char nameLayer;
    vector<Class*> classes;
public:
    int numOfClasses;
    Layer();
    virtual ~Layer();
    Class* isClassThere(int classIdx);
    vector<Class*> getClass();
    char getnameLayer();
    Class* getClass(int idx);
    void setnameLayer(char NameLayer);
    void addClass(Class* aClass);


};


#endif //ASSINGMENT3_LAYER_H
