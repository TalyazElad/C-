/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_SECRETARY_H
#define ASSINGMENT3_SECRETARY_H
#include "AdministrationPersonal.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>

class Secretary : public AdministrationPersonal{
private:
    int PupilsAtSchool ;
    int children;
public:
    Secretary();
    virtual ~Secretary();
    virtual float salary();
    virtual bool isSuccessful();
    virtual void printDetail();
    int getPupilsAtSchool();
    void setChildren(int c);

};


#endif //ASSINGMENT3_SECRETARY_H
