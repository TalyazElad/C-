/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_ADMINISTRATIONPERSONAL_H
#define ASSINGMENT3_ADMINISTRATIONPERSONAL_H
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Worker.h"

class AdministrationPersonal: virtual public Worker {
private:
    string officeLocation;
public:
    AdministrationPersonal();
    virtual ~AdministrationPersonal();
    string getOfficelocation();
    void setOfficelocation(string location);
    virtual float salary() = 0;
    virtual void printDetail() = 0;
};


#endif //ASSINGMENT3_ADMINISTRATIONPERSONAL_H
