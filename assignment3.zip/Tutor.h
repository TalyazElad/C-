/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_TUTOR_H
#define ASSINGMENT3_TUTOR_H
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Teacher.h"
#include "Class.h"

class Tutor:public Teacher {
private:
    Class* tutorClass ;
public:
    Tutor();
    virtual ~Tutor();
    Class* getClass();
    virtual float getSalary();
    void setClass(Class* TutorClass);
    virtual bool isSuccessful();
    virtual void printDetail();
};


#endif //ASSINGMENT3_TUTOR_H
