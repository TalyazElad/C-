/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Manager.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Teacher.h"
//default
Manager* Manager::manager = nullptr;
Manager::Manager() {}
Manager::~Manager() {}
// create new manager
Manager* Manager::createManager()
{
    if (manager != nullptr)
    {
        return nullptr;
    }else{
        return manager = new Manager;
    }
//    if (!manager)
//    {
//        return manager = new Manager();
//    }else{
//        return manager;
//    }
}
// checks if manager is successful
bool Manager::isSuccessful()
{
    if (Teacher::getManageYears()+Teacher::getTeachYears() > 3){return true;}
    return false;
}
// calculate the manager salary
float Manager::salary()
{
    float managmentsalary = (Worker::basis*2)+(Teacher::getManageYears()*500);
    if (isManagerTeach())
    {return managmentsalary+Teacher::salary();}
    else
    {
        return managmentsalary;
    }
}
// checks if the manager is teaching subjects
bool Manager::isManagerTeach()
{
    if (Teacher::numSubjects > 0){return true;}
    return false;
}

// print the manager details
void Manager::printDetail()
{
    cout << "Manager Name: " << Teacher::getFirstName() << " " << Teacher::getLastName() << endl;
    cout << "Manager Id: " << getId() << endl;
    cout << "Manager seniority: " << Teacher::getManageYears() << endl;
    if (isManagerTeach()){printSubjectTeacher();}
    cout << "The Manager salary is: " << salary() << endl;
    cout << "The location of the office: " << getOfficelocation() << endl;
}
