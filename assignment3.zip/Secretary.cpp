/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Secretary.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>

Secretary::Secretary() {
}
Secretary::~Secretary() {}

// calculate the secretary salary
float Secretary::salary()
{
    return basis+PupilsAtSchool*200;
}

// get the pupils at the school
int Secretary::getPupilsAtSchool()
{
    return PupilsAtSchool;
}

// check if the secretary is successful
bool Secretary::isSuccessful()
{
    if (getManageYears()+getTeachYears() > 10){return true;}
    return false;
}

// print the secretary details
void Secretary::printDetail()
{
    cout << "Secretary Name: " << getFirstName() << " " << getLastName() << endl;
    cout << "Secretary Id: " << getId() << endl;
    cout << "Secretary seniority: " << getTeachYears()+getManageYears() << endl;
    cout << "Number of children at school: " << PupilsAtSchool << endl;
    cout << "The Secretary salary is: " << salary() << endl;
    cout << "The location of the office: " << getOfficelocation() << endl;
}

// set the num of his/her children at the school
void Secretary::setChildren(int c) {
    PupilsAtSchool = c;

}
