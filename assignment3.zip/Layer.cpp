/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Layer.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>

using namespace std;

// sets the layer default
Layer::Layer()
{
    numOfClasses = 0 ;
    nameLayer = '0';
}
Layer::~Layer() {}

// get the name of the layer
char Layer::getnameLayer()
{
    return nameLayer;
}
// get the classes in the layer vector
vector<Class *> Layer::getClass()
{
    return classes;
}
// get the exact class in this layer
Class * Layer::getClass(int idx)
{
    if (idx < 4 && idx >0 )
    {
        return classes.operator[](idx - 1);
    }
    cout << "invalid index , please try again (1-3)" << endl;
    return nullptr ;
}

// sets the layer name
void Layer::setnameLayer(char NameLayer)
{
    nameLayer = NameLayer;
}

// checks if the class is already in this layer
Class * Layer::isClassThere(int classIdx)
{
    for (int i = 0; i < numOfClasses; ++i)
    {
        if (classes[i]->getClassNum() == classIdx)
        {
            return classes[i];
        }
    }
    return nullptr;
}

// add class to the layer vector
void Layer::addClass(Class *aClass)
{
    if (aClass)
    {
        if (numOfClasses < 3 )
        {
            numOfClasses ++ ;
            classes.emplace_back(aClass);
        }else
        {
            cout << "There are already 3 Classes" << endl;
        }

    }
}