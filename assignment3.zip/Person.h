/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_PERSON_H
#define ASSINGMENT3_PERSON_H
#include <iostream>
#include <string>
#include <cstring>
using namespace std;

class Person {
private:
    char *firstName;
    char *lastName;
    int ID ;
public:
    Person();
    void setFirstName(char *Firstname );
    void setLastName(char *Lastname);
    void setID(int id);
    int getId();
    virtual ~Person();
    char * getFirstName();
    char * getLastName();

    virtual //    void printPerson();
    bool isSuccessful();

};


#endif //ASSINGMENT3_PERSON_H
