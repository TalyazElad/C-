/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include <iostream>
#include "Person.h"
#include "Pupil.h"
#include "Worker.h"
#include "Teacher.h"
#include "Manager.h"
#include "VecAnalyser.h"
#include "School.h"
using namespace std;

int main() {
    School *s = School::getschool();
    s = s->createSchool();
    s->menu();
    cout<<"good bye!\n";
    delete (s);
    return 0;
}
