/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "Pupil.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
using namespace std;

// default
Pupil::Pupil()
{
    layer = 0;
    classNum = 0;
}

Pupil::~Pupil() {}

// set the pupil
void Pupil::setPupil(char Layer, int ClassNum)
{
    layer = Layer ;
    classNum = ClassNum;
}

// set the grades of the student
void Pupil::setGrades(int Grade)
{
    grades.push_back(Grade);
}

// get the pupil
Pupil Pupil::getPupil()
{
    return *this;
}

// get the pupil average grade
float Pupil::salary()
{
    AverageGrades = 0;
    float temp = 0;
    for (int i = 0; i < grades.size(); ++i)
    {
        temp += grades.at(i);
    }
    AverageGrades = temp/grades.size();
    return AverageGrades;
}

// is the pupil successful
bool Pupil::isSuccessful()
{
    salary();
    if (AverageGrades > 85)
    {
        for (int i = 0; i < grades.size(); ++i)
        {
            if (grades.at(i) < 65 ){return false;}
        }
        return true;
    }
    return false;
}

// print the pupil detail
void Pupil::printDetail()
{
    cout << "Pupil Name: " << getFirstName() << " " << getLastName() << endl;
    cout << "Pupil Id: " << getId() << endl;
    cout << "Class: " << layer << " " << classNum << endl;
    cout << "Grades: " ;
    for (int i = 0; i < grades.size(); ++i)
    {
        if (grades.empty())
        {
            cout << "There are no grades" << endl ;
        }
        if (i == grades.size() -1)
        {
            cout << grades.at(i) << endl;
            cout << "The Pupil Average is: " << salary() << endl;
            if (isSuccessful()){cout << "The pupil is successful !"<<endl;}
            else {cout << "The pupil is not successful !"<<endl;}
            break;
        }
        cout << grades.at(i) << "," ;
    }


}