/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "School.h"
#include "VecAnalyser.h"
#include "VecAnalyser.cpp"
#include "Tutor.h"

VecAnalyser<Pupil> P; //only to call function
VecAnalyser<Worker> W;//only to call function

// delete all the vectors
School::~School()
{
    for (int i = 0; i < vecPupil.size(); ++i) {
        delete vecPupil[i];

    }
    vecPupil.clear();
    for (int i = 0; i < vecWorker.size(); ++i) {
        delete vecWorker[i];

    }
    vecWorker.clear();
    for (int i = 0; i < layers.size(); ++i) {
        for (int j = 0; j < layers[i]->getClass().size(); ++j) {
            delete layers[i]->getClass()[j];
        }
        layers[i]->getClass().clear();
        delete layers[i];

    }
    layers.clear();
}

School* School::newschool = NULL;

// default
School::School()
{
    numOfLayers = 0;
    alreadymanager = 0;
}

// create the school vector
School * School::createSchool()
{
    if(!newschool)
    {
        return newschool = new School();
    }
    return newschool;
}

// gets the layer
vector<Layer *> School::getLayer()
{
    return layers;
}

// start the menu - options of selection
void School::menu() {
    vector<int> grades;
    vector <string> courses;
    int c;
    cout << "~~~~~~~~~~~~~~~~~~~~~~" << endl;
    cout << "1. Add Pupil" << endl;
    cout << "2. Add teacher" << endl;
    cout << "3. Add Tutor" << endl;
    cout << "4. Add manager" << endl;
    cout << "5. Add Secretary" << endl;
    cout << "6. Print person details" << endl;
    cout << "7. Print outstanding people" << endl;
    cout << "8. Print tutor’s class" << endl;
    cout << "9. Highest paid worker" << endl;
    cout << "10.Exit" << endl;
    cout << "~~~~~~~~~~~~~~~~~~~~~~" << endl;
    cin >> c;
    switch (c) {
        case 1:
            Addpupil();
            break;
        case 2:
            Addteacher();
            break;
        case 3:
            Addtutor();
            break;
        case 4:
            Addmanager();
            break;
        case 5:
            Addsecretary();
            break;
        case 6:
            Printpersondetails();
            break;
        case 7:
            Printoutstandingpeople();
            break;
        case 8:
            Printtutorclass();
            break;
        case 9:
            Highestpaidworker();
            break;
        case 10:
            break;
        default:
            cout<<"Wrong input, please try again"<<endl;
            menu();
    }

}

// add pupil to the school list
void School::Addpupil()
{
    Pupil *pupil = new Pupil();
    char anotherinput;
    string inputpupil,inputpupil2;
    Layer *layer;
    Class* cLass;
    int c , vamos = 1 , grade,id;
    cout << "Enter first name: " <<endl;
    cin.ignore();
    getline(cin,inputpupil,'\n');
    char * name = const_cast<char *>(inputpupil.data());
    pupil->setFirstName(name);
    cout << "Enter last name: " <<endl;
    getline(cin,inputpupil2,'\n');
    char * lastname = const_cast<char *>(inputpupil2.data());
    pupil->setLastName(lastname);
    cout << "Enter ID: "<<endl;
    cin >> id;
    if(serachById(id) != 0)
    {
        cout << "Id already exist!"<< endl;
        menu();
        return;
    }
    pupil->setID(id);
    cout << "Enter layer: " <<endl;
    cin >> anotherinput;
    cout << "Enter Class number: "<<endl;
    cin >> c;
    while(c<1 ||c>3)
    {
        cout<<"Please try again, number class 1-3."<<endl;
        cin>>c;
    }
    while(anotherinput<'a' ||anotherinput>'f')
    {
        cout<<"Please try again, layer a-f."<<endl;
        cin>>anotherinput;
    }
    if (!checkLayer(anotherinput))
    {
        //if no layer create new one and class
        layer = new Layer();
        layer->setnameLayer(anotherinput);
        cLass = new Class();
        cLass->setClassNum(c);
        cLass->setLayer(anotherinput);
        cLass->addPupiltoClass(pupil);
        layer->addClass(cLass);
        addlayer(layer);

    } else
    {
        // if there is a layer
        layer = checkLayer(anotherinput);
        // if there isnt a class like above
        if (!layer->isClassThere(c))
        {
            cLass = new Class();
            cLass->setClassNum(c);
            cLass->setLayer(anotherinput);
            cLass->addPupiltoClass(pupil);
            layer->addClass(cLass);
        } else // if there is a class like above
        {
            cLass = layer->isClassThere(c);
            cLass->addPupiltoClass(pupil);
        }
    }
    pupil->setPupil(anotherinput,c);
    while (vamos)
    {
     cout << "Enter the grade: "<<endl;
     cin >> grade;
     pupil->setGrades(grade);
     cout << "Do you want to add more grades? (0/1) "<<endl;
     cin >> vamos;
    }
    pupil->salary();
    vecPupil.push_back(pupil);
    menu();

}


// add teacher to the school list
void School::Addteacher()
{
    Teacher *teacher = new Teacher();
    string inputpupil,inputpupil2;
    int c ,s, vamos = 1 ,id;
    cout << "Enter first name: " <<endl;
    cin.ignore();
    getline(cin,inputpupil,'\n');
    char * name = const_cast<char *>(inputpupil.data());
    teacher->setFirstName(name);
    cout << "Enter last name: " <<endl;
    getline(cin,inputpupil2,'\n');
    char * lastname = const_cast<char *>(inputpupil2.data());
    teacher->setLastName(lastname);
    cout << "Do you teach? (0/1)" <<endl;
    cin >> vamos;
    if (!vamos)
    {
        cout << inputpupil << " " << inputpupil2 << "isn't a teacher" <<endl;
        delete teacher;
        menu();
        return;
    }
    cout << "Enter ID: " <<endl;
    cin >> id;
    if(serachById(id) != 0)
    {
        cout << "Id already exist!"<< endl;
        menu();
        return;
    }
    teacher->setID(id);
    while (vamos)
    {
        string subject;
        cout << "Enter the subject: "<<endl;
        cin >> subject;
        char * subjects = const_cast<char *>(subject.data());
        teacher->setTeacherSubject(subjects);
        cout << "Do you want to add more subjects? (0/1) "<<endl;
        cin >> vamos;
    }
    cout << "How many years of teaching? "<<endl;
    cin >> c;
    teacher->setTeachYears(c);
    cout << "How many years of managing? "<<endl;
    cin >> s;
    teacher->setmanageYears(s);
    vecWorker.push_back(teacher);
//    W.printElement(vecWorker,0);
    menu();

}

// add tutor to the school list
void School::Addtutor()
{
    Tutor *tutor = new Tutor();
    Layer *layer;
    Class* cLass;
    string inputpupil,inputpupil2;
    int c ,s, vamos = 1 , classnum , id;
    char classlay;
    cout << "Enter first name: " <<endl;
    cin.ignore();
    getline(cin,inputpupil,'\n');
    char * name = const_cast<char *>(inputpupil.data());
    tutor->setFirstName(name);
    cout << "Enter last name: " <<endl;
    getline(cin,inputpupil2,'\n');
    char * lastname = const_cast<char *>(inputpupil2.data());
    tutor->setLastName(lastname);
    cout << "Enter ID: "<<endl;
    cin >> id;
    if(serachById(id) != 0)
    {
        cout << "Id already exist!" << endl;
        menu();
        return;
    }
    tutor->setID(id);
    cout << "Do you teach? (0/1) "<<endl;
    cin >> vamos;
    while (vamos)
    {
        string subject;
        cout << "Enter the subject: "<<endl;
        cin >> subject;
        char * subjects = const_cast<char *>(subject.data());
        tutor->setTeacherSubject(subjects);
        cout << "Do you want to add more subjects? (0/1)"<<endl;
        cin >> vamos;
    }
    cout << "Which class number do you tutoring? "<<endl;
    cin >> classnum;
    cout << "Which layer? "<<endl;
    cin >> classlay;
    while(classnum<1 ||classnum>3)
    {
        cout<<"Please try again, number class 1-3."<<endl;
        cin>>classnum;
    }
    while(classlay<'a' ||classlay>'f')
    {
        cout<<"Please try again, layer a-f."<<endl;
        cin>>classlay;
    }
    if (!checkLayer(classlay))
    {
        //if no layer create new one and class
        layer = new Layer();
        layer->setnameLayer(classlay);
        cLass = new Class();
        cLass->setClassNum(classnum);
        cLass->setLayer(classlay);
        cLass->setTutor(tutor);
        layer->addClass(cLass);
        tutor->setClass(cLass);
        addlayer(layer);

    } else
    {
        // if there is a layer
        layer = checkLayer(classlay);
        // if there isnt a class like above
        if (!layer->isClassThere(classnum))
        {
            cLass = new Class();
            cLass->setClassNum(classnum);
            cLass->setLayer(classlay);
            cLass->setTutor(tutor);
            layer->addClass(cLass);
            tutor->setClass(cLass);
        } else // if there is a class like above
        {
            cLass = layer->isClassThere(classnum);
            cLass->setTutor(tutor);
            tutor->setClass(cLass);
        }
    }
    cout << "How many years of teaching? "<<endl;
    cin >> c;
    tutor->setTeachYears(c);
    cout << "How many years of managing? "<<endl;
    cin >> s;
    tutor->setmanageYears(s);
    tutor->salary();
    vecWorker.push_back(tutor);
    menu();
}

// gets the newschool
School *School::getschool() {
    return newschool;
}

// add Manager to the school list
void School::Addmanager()
{
    if (alreadymanager)
    {
        cout << "There is already Manager in our school!"<<endl;
        menu();
        return;
    }
    Manager* manager = Manager::createManager();
    alreadymanager = 1;
    string inputpupil,inputpupil2;
    int c ,s, vamos = 1 , classnum,my,ty,id;
    char classlay;
    string location;
    cout << "Enter first name: " <<endl;
    cin.ignore();
    getline(cin,inputpupil,'\n');
    char * name = const_cast<char *>(inputpupil.data());
    cout << "Enter last name: "<<endl;
    getline(cin,inputpupil2,'\n');
    char * lastname = const_cast<char *>(inputpupil2.data());
    manager->setFirstName(name);
    manager->setLastName(lastname);
    cout << "Enter ID: "<<endl;
    cin >> id;
    if(serachById(id) != 0)
    {
        cout << "Id already exist!"<< endl;
        menu();
        return;
    }
    manager->setID(id);
    cout << "Location of your office: " << endl;
    cin.ignore();
    getline(cin,location,'\n');
    manager->setOfficelocation(location);
    cout << "Do you teach? (0/1) "<<endl;
    cin >> vamos;
    while (vamos)
    {
        string subject;
        cout << "Enter the subject: "<<endl;
        cin >> subject;
        char * subjects = const_cast<char *>(subject.data());
        manager->setTeacherSubject(subjects);
        cout << "Do you want to add more subjects? (0/1) "<<endl;
        cin >> vamos;
    }
    cout << "How many years of management? "<<endl;
    cin >> my;
    cout << "How many years of teaching? "<<endl;
    cin >> ty;
    manager->setmanageYears(my);
    manager->setTeachYears(ty);
    vecWorker.push_back(manager);
    menu();

}

// add secretary  to the school list
void School::Addsecretary()
{
    Secretary *secretary = new Secretary();
    string inputpupil,inputpupil2;
    int c ,s, vamos = 1 , classnum,id;
    char classlay;
    string location;
    cout << "Enter first name: " <<endl;
    cin.ignore();
    getline(cin,inputpupil,'\n');
    char * name = const_cast<char *>(inputpupil.data());
    cout << "Enter last name: " <<endl;
    getline(cin,inputpupil2,'\n');
    char * lastname = const_cast<char *>(inputpupil2.data());
    secretary->setFirstName(name);
    secretary->setLastName(lastname);
    cout << "Enter ID: "<<endl;
    cin >> id;
    if(serachById(id) != 0)
    {
        cout << "Id already exist!"<< endl;
        menu();
        return;
    }
    secretary->setID(id);
    cout << "Location of your office: " <<endl;
    cin.ignore();
    getline(cin,location,'\n');
    secretary->setOfficelocation(location);
    cout << "How many children? "<<endl;
    cin >> c;
    secretary->setChildren(c);
    cout << "How many years works here? "<<endl;
    cin >> s;
    secretary->setmanageYears(s);
    vecWorker.push_back(secretary);
    menu();
}

// print every person in the school
void School::Printpersondetails()
{
    W.printAll(vecWorker);
    P.printAll(vecPupil);
    menu();
}

// print the successful people
void School::Printoutstandingpeople()
{
    int countpupil = 0 , countworkers = 0 ;
    cout << "The successful pupils are: " << endl;
    for (int i = 0; i < vecPupil.size(); ++i) {
        if (vecPupil[i]->isSuccessful())
        {
            P.printElement(vecPupil,i);
            countpupil ++;
        }
    }
    if (!countpupil)
    {
        cout << "Unfortunately there are no successful pupuils." << endl;
        cout << endl;
    }
    cout << "The successful workers are: " << endl;
    for (int i = 0; i < vecWorker.size(); ++i) {
        if (vecWorker[i]->isSuccessful())
        {
            W.printElement(vecWorker,i);
            countworkers ++ ;
        }
    }
    if (!countworkers)
    {
        cout << "Unfortunately there are no successful workers." << endl;
        cout << endl;
    }
    menu();
}

// print the tutor's class by ID
void School::Printtutorclass()
{
    int id ;
    int i;
    cout << "Enter the tutor ID: "<<endl;
    cin >> id ;
    if(serachById(id) != 1)
    {
        cout << "There is no such tutor!"<<endl;
        menu();
        return;
    }
    for ( i = 0; i < vecWorker.size(); ++i) {
        if (vecWorker[i]->getId() == id)
        {
            Tutor *thisone = dynamic_cast<Tutor *>(vecWorker[i]);
            thisone->getClass()->printClass();
        }
    }
    menu();

}

// print the highest paid worker
void School::Highestpaidworker()
{
    W.printMax(vecWorker);
    menu();
}

// serach the person by ID
int School::serachById(int id) {
    for (int i = 0; i < vecWorker.size(); ++i) {
        if (vecWorker[i]->getId() == id)
        {
            if (typeid(*vecWorker[i]) == typeid(Tutor)){return 1;}
            if (typeid(*vecWorker[i]) == typeid(Secretary)){return 2;}
            if (typeid(*vecWorker[i]) == typeid(Teacher)){return 3;}
            if (typeid(*vecWorker[i]) == typeid(Manager)){return 4;}

        }

    }
    for (int i = 0; i < vecPupil.size(); ++i) {
        if (vecPupil[i]->getId() == id)
        {
            return 5;
        }

    }
    return 0;

}

// check if the layer exist
Layer* School::checkLayer(char layer)
{
    for (int i = 0; i < layers.size(); ++i) {
        if (layers[i]->getnameLayer() == layer)
        {
            return layers[i];
        }
    }
    return nullptr;
}

// add layer the the layers vector
void School::addlayer(Layer* layer)
{
    layers.push_back(layer);
    countlayer ++;
}
