/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_PUPIL_H
#define ASSINGMENT3_PUPIL_H
#include "Person.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
using namespace std;

class Pupil: public Person {
private:
    vector<int> grades;
    char layer ;
    int classNum;
    float AverageGrades ;
public:
    Pupil();
    virtual ~Pupil();
    void setPupil(char Layer , int ClassNum);
    void setGrades(int Grade);
    float salary();
    Pupil getPupil();
    virtual bool isSuccessful();
    void printDetail();


};


#endif //ASSINGMENT3_PUPIL_H
