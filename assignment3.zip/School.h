/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#ifndef ASSINGMENT3_SCHOOL_H
#define ASSINGMENT3_SCHOOL_H
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Layer.h"
#include "Class.h"
#include "Worker.h"
#include "VecAnalyser.h"

class School {
private:
    vector<Layer*> layers;
    int numOfLayers;
//    vector<Pupil*> Pupils;
    static School* newschool;
    void Addpupil();
    void Addteacher();
    void Addtutor();
    void Addmanager();
    void Addsecretary();
    void Printpersondetails();
    void Printoutstandingpeople();
    void Printtutorclass();
    void Highestpaidworker();
    void addlayer(Layer* layer);
    int countlayer;
public:
    vector<Pupil*> vecPupil;
    vector<Worker*> vecWorker;
    vector<Layer*> getLayer();
    static School* createSchool();
    void menu();
    int alreadymanager ;
    virtual ~School();
    int serachById(int id);

    School();

    static School *getschool();

    Layer *checkLayer(char layer);

    void checkClass(int cLass);
};


#endif //ASSINGMENT3_SCHOOL_H
