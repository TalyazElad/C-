/* Assignment: 1
Author1: Elad Talyaz,
ID: 315326520
Author2: Yael Biton,
ID: 206888661
*/

#include "AdministrationPersonal.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "Worker.h"

AdministrationPersonal::AdministrationPersonal() {}
AdministrationPersonal::~AdministrationPersonal() {}
// saves the location
void AdministrationPersonal::setOfficelocation(string location)
{
    officeLocation = location;
}
//return the location
string AdministrationPersonal::getOfficelocation()
{
    return officeLocation;
}


